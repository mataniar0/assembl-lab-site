V364 — קבצי חיתוך לייצור על לוחות 900×440 מ"מ

Sheet 1:
Rail A ×4
Rail B ×4

Sheet 2:
Top Plate TP1 ×1
Shelf Slat ×10

Sheet 3:
Shelf Support LS ×4
Top Perimeter ×4
Decorative Arch ×4

בדיקות:
- כל החלקים בתוך 900×440.
- אין חפיפות בין חלקים.
- הכמויות נבדקו מול BOM.
- גאומטריית V364 לא שונתה; רק סידור החיתוך.
- אין פיצוי Kerf.

שכבות:
CUT = חיתוך.
SHEET_GUIDE = מסגרת הלוח בלבד, לא לחיתוך.
